package flag;

import java.awt.Color;

public class Main {
	public static void main(String[] args) {
	Flag c = new Flag();
	c.setDefaultCloseOperation(c.EXIT_ON_CLOSE);
	c.getContentPane().setBackground(Color.PINK);
	c.setVisible(true);
	}
}
