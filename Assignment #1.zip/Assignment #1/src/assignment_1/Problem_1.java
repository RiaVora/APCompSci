package assignment_1;

public class Problem_1 {
	public static void main (String[] args) {
		pln(ret() + "");
	}
	
	public static int ret () {
		return 17;
	}
	
	public static void p (String args) {
		System.out.print(args);
	}

	public static void pln (String args) {
		System.out.println(args);
	}

}
